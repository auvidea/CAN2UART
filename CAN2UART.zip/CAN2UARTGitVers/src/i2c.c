/*
   Copyright (C) 2017 Auvidea GmbH

   This file is part of Project CAN2UART

   CAN2UART is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   CAN2UART is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with AutoQuad.  If not, see <http://www.gnu.org/licenses/>.
   

   Copyright � 2015 STMicroelectronics International N.V.. All rights reserved.

   Redistribution and use in source and binary forms, with or without modification,
   are permitted, provided that the following conditions are met:

   1.	Redistribution of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
   2.	Redistributions in binary form must reproduce the above copyright notice,
        this list of conditions and the following disclaimer in the documentation
        and/or other materials provided with the distribution.
   3.	Neither the name of STMicroelectronics nor the names of other contributors
        to this software may be used to endorse or promote products derived from 
        this software without specific written permission.
   4.	This software, including modifications and/or derivative works of this
        software, must execute solely and exclusively on microcontroller or 
        microprocessor devices manufactured by or for STMicroelectronics.
   5.	Redistribution and use of this software other than as permitted under
        this license is void and will automatically terminate your rights under
        this license. 

   THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS,
   IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY    
   INTELLECTUAL PROPERTY RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. 
   IN NO EVENT SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
   INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
   OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
   WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
   ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
   OF SUCH DAMAGE.
*/


#include <stdio.h>
#include "i2c.h"
#include "usart.h"

void write_I2C(void) {
	I2C_WrReg(i2cData.device_address, i2cData.register_address, i2cData.tx_values, i2cData.number_values); // &TxData: an array is no pointer! http://www.mikrocontroller.net/topic/73475
}

void read_I2C(mode) {
	int i, j;
	uint16_t ret = 0; // return error
	ret = I2C_RdReg(i2cData.device_address, 0x00, i2cData.rx_values, 1, 1);
	if (ret == BAD_DEV_ADDR) {
		return;
	} else {
		if(mode==1) {
			USART_WriteString("     0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F\r\n");
			for(j=0; j<16; j++) {
				snprintf(usartStr, 5, "%X0: ", j);
				USART_WriteString(usartStr);
				I2C_RdReg(i2cData.device_address, i2cData.register_address, i2cData.rx_values, 16, 1);
				for(i=0; i<16; i++){
					snprintf(usartStr, 5, "%.2X ", i2cData.rx_values[i]);
					USART_WriteString(usartStr);
					i2cData.register_address++;
				}
				USART_WriteString("\r\n");
			}
		} else if(mode==2) {
			I2C_RdReg(i2cData.device_address, i2cData.register_address, i2cData.rx_values, i2cData.number_values, 1);
			for(i=0; i<i2cData.number_values; i++) {
				snprintf(usartStr, 40, "reg: 0x%.2X data: 0x%.2X\r\n", i2cData.register_address++, i2cData.rx_values[i]);
				USART_WriteString(usartStr);
			}

		}
	}
}

void list_I2C(void) {
	int i = 0, j = 0;
	int ret = 0;
	uint8_t DevAddr = 3;
	USART_WriteString("responding I2C devices:\r\n");
	USART_WriteString("     0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F\r\n");
	for(j=0; j<8; j++) {
		snprintf(usartStr, 5, "%X0: ", j);
		USART_WriteString(usartStr);
		for(i=0; i<16; i++){
			if ( (j==0 && (i == 0 || i == 1 || i == 2)) || (j==7 && (i == 8 || i == 9 || i == 10 || i == 11 || i == 12 || i == 13 || i == 14 || i == 15)) ) {
				USART_WriteString("   ");
			} else {
				ret = I2C_listDev(DevAddr);
				if (ret==0){
					snprintf(usartStr, 10, "%.2X ", DevAddr);
					USART_WriteString(usartStr);
					DevAddr = DevAddr + 1;
				} else {
					USART_WriteString("-- ");
					DevAddr = DevAddr + 1;
				}
			}
		}
		USART_WriteString("\r\n");
	}
}
