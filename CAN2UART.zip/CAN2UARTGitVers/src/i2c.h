/*
   Copyright (C) 2017 Auvidea GmbH

   This file is part of Project CAN2UART

   CAN2UART is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   CAN2UART is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with AutoQuad.  If not, see <http://www.gnu.org/licenses/>.
   

   Copyright � 2015 STMicroelectronics International N.V.. All rights reserved.

   Redistribution and use in source and binary forms, with or without modification,
   are permitted, provided that the following conditions are met:

   1.	Redistribution of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
   2.	Redistributions in binary form must reproduce the above copyright notice,
        this list of conditions and the following disclaimer in the documentation
        and/or other materials provided with the distribution.
   3.	Neither the name of STMicroelectronics nor the names of other contributors
        to this software may be used to endorse or promote products derived from 
        this software without specific written permission.
   4.	This software, including modifications and/or derivative works of this
        software, must execute solely and exclusively on microcontroller or 
        microprocessor devices manufactured by or for STMicroelectronics.
   5.	Redistribution and use of this software other than as permitted under
        this license is void and will automatically terminate your rights under
        this license. 

   THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS,
   IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY    
   INTELLECTUAL PROPERTY RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. 
   IN NO EVENT SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
   INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
   OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
   WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
   ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
   OF SUCH DAMAGE.
*/


#include <stdint.h>

#ifndef I2C_H_
#define I2C_H_

//see https://github.com/pyrohaz/STM32F0-HMC5883_Barebones/blob/master/main.c
#define EP9351_SDA GPIO_Pin_11
#define EP9351_SCL GPIO_Pin_10
#define EP9351_GPIO GPIOB
#define EP9351_SDA_PS GPIO_PinSource11
#define EP9351_SCL_PS GPIO_PinSource10
#define EP9351_PIN_AF GPIO_AF_1
#define EP9351_I2C I2C1
#define I2C_TIMEOUT 1000

#define HDMI_IN			((uint8_t)0x3C)
#define EP9351_ADDR		((uint8_t)0x3C)

typedef struct {
    uint8_t device_address;
    uint8_t register_address;
    uint8_t number_values;
    uint8_t tx_values[256];
    uint8_t rx_values[256];
} i2cStruct_t;
extern i2cStruct_t i2cData;

enum de_mode { DE_ON = 0 , DE_OFF };
enum de_mode de_mode;
extern void chipReset(void);
extern void i2cInit(void);
extern void bbInit(void);
extern void i2c_wr_byte(uint8_t Addr, uint8_t Reg, uint8_t DataByte);
extern uint8_t i2c_rd_byte(uint8_t Addr, uint8_t Reg);
extern uint16_t I2C_WrReg(uint8_t Addr, uint8_t Reg, const uint8_t *Data, uint16_t DCnt);
extern uint16_t I2C_RdReg(uint8_t Addr, uint8_t Reg, uint8_t *Data, uint8_t DCnt, uint8_t incr);
extern uint16_t I2C_listDev(uint8_t Addr);
extern void init_EP9351(void);
extern void rd_avi(void);
extern void pr_avi(void);
extern void init_edid(void);

#endif /* I2C_H_ */
